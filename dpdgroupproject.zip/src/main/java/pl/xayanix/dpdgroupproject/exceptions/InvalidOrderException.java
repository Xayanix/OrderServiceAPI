package pl.xayanix.dpdgroupproject.exceptions;

public record InvalidOrderException(String errorMessage) { }
